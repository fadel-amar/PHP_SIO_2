<?php

/*
 * Exercice 7 : fuseau horaire d'un objet DateTime
 */

// Créer un objet DateTime avec la date du jour et l'heure courante

// Afficher le fuseau horaire de l'objet

echo PHP_EOL;
// Modifier le fuseau horaire de l'objet pour qu'il soit à New York

// Afficher la date du jour au format jj/mm/aaaa hh:mm

echo PHP_EOL;
// Créer un objet DateTime avec la date du jour et l'heure courante et le fuseau horaire de New York

// Afficher la date du jour au format jj/mm/aaaa hh:mm

echo PHP_EOL;
