<?php

/*
 * Exercice 5 : Modification d'objets DateTime avec les méthodes add et sub
 */

// Créer un objet DateTime avec la date du 22/06/2019 à 9h15

// Ajouter 1 mois à la date

// Afficher la date au format jj/mm/aaaa hh:mm

echo PHP_EOL;
// Ajouter 2 ans, 3 mois, 1 jour, 4 heures, 5 minutes et 6 secondes à la date

// Afficher la date au format jj/mm/aaaa hh:mm

echo PHP_EOL;
// Retirer 1 mois à la date et 2 heures et 30 minutes à la date

// Afficher la date au format jj/mm/aaaa hh:mm

echo PHP_EOL;
