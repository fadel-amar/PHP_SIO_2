/*
 *  Les variables
 */

// Déclaration d'une variable
let nombre = 12
console.log(nombre)
nombre = 15
console.log(nombre)

// Déclaration d'une constante
//console.clear()
const nombre2 = 12
console.log(nombre2)
//nombre2 = 15 Erreur

// Déclaration d'une variable initialisée sans valeur explicite : null
//console.clear()
let age = null
console.log(age)
age += 1 // age = age +1
console.log(age)

// Déclaration d'une variable non initialisée
//console.clear()
let nombre3
console.log(nombre3)
nombre3 += 1
console.log(nombre3)
